package kapitel1; // Den här raden berättar att denna Java-klass ligger i ett package med namnet kapitel1

public class Uppgifter {  // Här börjar Java-klassen Uppgifter. Klassnamnet måste vara samma som filnamnet.

    public static void main(String[] args) {  // Detta är main-metoden. Här börjar programmet köra om kompileringen går igenom.
        uppgift1();  // Anrop till metoden uppgift1
        uppgift2();  // Anrop till metoden uppgift2
        uppgift3();  // Detta anrop är bortkommenterat så att koden ignorerar det.
        uppgift4(); // Också bortkommenterat, ta bort kommentaren om du vill att koden ska anropa uppgift4.
    }

    static void uppgift1() {
        System.out.println("Linus Gerdin"); // En rad som skriver ut mitt namn
        System.out.println("Platåvägen 28");   // En annan rad som skriver ut min adress
        System.out.println("191 36"); // Mitt postnummer
    }

    static void uppgift2() {
        System.out.println("");
        System.out.println("Linus Gerdin");
        System.out.println("");
        System.out.println("Platåvägen 28");
        System.out.println("191 36");
        // TODO: Fixa en blankrad mellan namn och adress...
    }

    static void uppgift3() {
        System.out.println("JJJJJ   JJJ   J   J   JJJ");
        System.out.println("    J  J   J  J   J  J   J");
        System.out.println("    J  J   J   J J   J   J");
        System.out.println("J   J  JJJJJ   J J   JJJJJ");
        System.out.println(" JJJ   J   J    J    J   J");



    }


    static void uppgift4() {
        //System.out.println(
    }

} // Denna "måsvinge" stänger hela klassen "Uppgifter"