package kapitel4;

public class Uppgifter {

    public static void main(String[] args) {
        uppgift4_1();
    }

    private static void uppgift4_1() {




    }
}
