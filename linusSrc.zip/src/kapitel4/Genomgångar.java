package kapitel4;

public class Genomgångar {

    public static void main(String[] args) {
        //exempel1();
        //exempel2();
        exempel3();


    }

    private static void exempel3() {

        int a = 5;
        int b = 3;

        System.out.println(a*=b);

    }

    private static void exempel2() {
        int räknare = 0;
        räknare++;


    }

    private static void exempel1() {
        System.out.println(3 + 7); //10

        System.out.println(7/4); //1, inga decimaltal

        double d = 10/4;
        System.out.println(d); //2.0

        //modulu %, är resten vid heltalsdivision

        System.out.println(10 % 4); //2
        System.out.println(9 % 2); //1
        System.out.println(8 % 2); //0
        System.out.println(1337 % 10); //7


    }

}
