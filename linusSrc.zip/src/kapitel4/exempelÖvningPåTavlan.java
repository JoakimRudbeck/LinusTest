package kapitel4;

public class exempelÖvningPåTavlan {
    public static void main(String[] args) {
        exempelÖvning();
    }

    private static void exempelÖvning() {

        int[] f = new int [3]; //att skapa ett fält<
        f[0] = 7;
        f[1] = 8;
        f[2] = 13;

        int[] f2 = {7,8,13,}; //ett annat sätt att skapa fält
        System.out.println(f2);



    }


}
