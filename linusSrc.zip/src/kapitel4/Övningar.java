package kapitel4;

import java.util.Scanner;

public class Övningar {
    static Scanner Scanner = new Scanner(System.in);

    public static void main(String[] args) {
        //Övning4_1();
        //Övning4_2();
        //Övning4_4();
        Övning4_5();
    }

    private static void Övning4_5() {// vilka värden får variablerna i följande något konstrurade satser


        int tal1 = 5 + 6%4; // 7
        int tal2 = (5 + 6)%4; // 3
        double tal3 = 5;
        tal3 *= 2.5 + 1; // 17.5

        System.out.println(tal1);
        System.out.println(tal2);
        System.out.println(tal3);



    }

    private static void Övning4_4() { //tillverka ett program som visar att resultaten blir olika för utskrifterna
        int tal1 = 10;
        int tal2 = 10;



        System.out.println("Ifall -- är innan talet blir det " + --tal1);

        System.out.println("Ifall -- är efter talet blir det " + tal2--);

        System.out.println("Vilket betyder att om -- är innan skriver det ut det nya talet medans -- efter skirver ut orginaltalet.");



    }




    private static void Övning4_2() { //Tillverka ett program som ombandlar en av användarens inmatad tidsangivelse i
        // månader till år o månader

        System.out.println("Skriv in ett antal månader");


        int månad = Integer.valueOf(Scanner.nextLine());
        int åromånad = månad/12;
        int månadsår = månad % 12;



        System.out.println(månadsår + " månader och " + åromånad + " år");


    }

    private static void Övning4_1() { //Byt typ int mot double
        Scanner scanner = new Scanner(System.in);
        double tal1, tal2;
        System.out.println("Mata in 2 heltal vettja");
        tal1 = scanner.nextDouble();
        tal2 = scanner.nextDouble();

        System.out.println(tal1 + " / " + tal2 + " = " + tal1/tal2);
        System.out.println(tal1 + " % " + tal2+ " = " + tal1%tal2);

    }


}
