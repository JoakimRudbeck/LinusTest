import java.util.Scanner;

public class PROV_KAP1_4_LINUS_GERDIN_RÄTTAD {

    /*
    Bedömning från Joakim:
    Du löser i princip de fyra första uppgifterna dock missar du följande:
    Då du ska ta ut första halvan av namnet då antar du att alla förnamn har 6 tecken. -1p
    Men om man heter Bo ska enbart B skrivas och om man heter Gabriella ska Gabri skrivas ut.
    Testa att skriva in att du heter Bo så kommer du få exekveringsfel.

    I övrigt bra med kommentarer och god struktur.

    Poäng: 9 av 12
    Betyg: E
     */

    static Scanner Scanner = new Scanner(System.in); //gör en scanner

    public static void main(String[] args) {
        //Vad användarens namn är
        System.out.println("Vad heter du?"); //frågar användaren vad hen heter
        String namn = Scanner.nextLine(); //en scanner där användaren kommer att skriva in sitt namn.


        //Hur många bokstäver som namnet består av
        int längd = namn.length(); //detta beräknar hur många bokstäver som finns i variabeln namn
        System.out.println("Du heter " + namn.toUpperCase() + " och ditt namn består av " + längd + " bokstäver");
        //skriver ut vad man heter i stora bokstäver genom att använda toUpperCase


        //att skriva in ett heltal
        System.out.println("Skriv in ett heltal"); //ber användaren skriva in ett heltal
        int a = Integer.valueOf(Scanner.nextLine()); //En scanner som tar in vad användaren skriver, till variabeln a

        System.out.println("Skriv in ett till heltal"); //samma sak fast för variablen b
        int b = Integer.valueOf(Scanner.nextLine());


        int summan = a + b; //beräknar summan av a+b
        System.out.println("Summan av talen du skrivit in är " + summan);

        int produkten = a * b; //beräknar produkten
        System.out.println("Produkten av dina tal är " + produkten);

        int modulu = a % b; //beräknar resten
        System.out.println("Resten som blir när du dividerar a och b blir " + modulu);


        //skapa ett fält med frutkter


        String[] frukter = new String[4]; //gör ett fält

        for (int i = 0; i < 4; i++) {
            System.out.println("Frukt" + (i + 1) + "?");        //en loop istället för fält
            frukter[i] = Scanner.nextLine();
        }


        System.out.println("Alla frukter i fältet");{
        for (int i = 0; i <= 3; i++)
            System.out.println(frukter[i]);
    }



        //byta plats och ändra i fältet


        String temp = frukter[0]; //byter plats på första o sista platsen
        frukter[0] = frukter [3];
        frukter[3] = temp;

        frukter[1] = "KIWI"; //byter namn till KIWI


        frukter[2] = namn.substring(0,3); // halva namnet

        //skriver ut det nya fältet en sista gång
        System.out.println("Alla värden i fältet efter ändringarna:");
        System.out.println(frukter[0]);
        System.out.println(frukter[1]);
        System.out.println(frukter[2]);
        System.out.println(frukter[3]);






    }
}
