package kapitel3;

import java.util.Scanner;

public class Övningar {

    public static void main(String[] args) {
       // Övning3_1();
        Övning3_2();


    }

    private static void Övning3_2() {
        Scanner scanner = new Scanner(System.in);
        int[] tal = new int [3];
        System.out.println("Skriv in 3 heltal: ");
        tal[0] = scanner.nextInt();                 //Hur man skapar ett fält
        tal[1] = scanner.nextInt();
        tal[2] = scanner.nextInt();

        int temp = tal[0];
        tal[0] = tal[2];
        tal[2] = temp;                          //hur man byter plats på fält
        System.out.println("Talen i fältet är:" +
                "" + tal[0]+ " " + tal[1]+ " " + tal[2]);

    }

    private static void Övning3_1() { //skriv ett program som defienerar ett heltalsfält med fyra pos.
        Scanner scanner = new Scanner(System.in);

        int[] heltalsFält =  new int[4];

        System.out.println("Värde 1?");
        heltalsFält[0] = Integer.valueOf(scanner.nextLine());
        System.out.println("Värde 2?");
        heltalsFält[1] = Integer.valueOf(scanner.nextLine());
        System.out.println("Värde 3?");
        heltalsFält[2] = Integer.valueOf(scanner.nextLine());
        System.out.println("Värde 4?");
        heltalsFält[3] = Integer.valueOf(scanner.nextLine());

        System.out.println("Värdena i fältet:");
        System.out.println((heltalsFält[0]));
        System.out.println((heltalsFält[1]));
        System.out.println((heltalsFält[2]));
        System.out.println((heltalsFält[3]));









    }





    }



