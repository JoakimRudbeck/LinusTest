package kapitel3;

public class chat {

    public static void main(String[] args) {
        String[] elever = {"Simon", "Linus", "Axel"};

        for(String elev : elever){
            String namn = elev;
            int nummer = namn.hashCode();
            int tal = nummer % 10;
            System.out.println(elev + "-->" + tal);

        }
    }
}
