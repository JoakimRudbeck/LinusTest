package kapitel_9;

import java.util.Scanner;

public class Övningar {
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        //Övning9_1();
        //Övning9_2();
        Övning9_3();


    }

    private static void Övning9_3() {
        


    }

    private static void Övning9_2() {
        System.out.println("skriv in radie och höjd din b");
        double r = Double.valueOf(scanner.nextLine());
        double h = Double.valueOf(scanner.nextLine());

        double v = volymCylinder(r,h);

        System.out.println("volym är " + v);

        }

    static double volymCylinder(double radie, double höjd){
        double volym = Math.PI*radie*radie*höjd;
        return volym;

        }

    private static void Övning9_1() {
        System.out.println("skriv in då din noob");
        double r = Double.valueOf(scanner.nextLine());
        double a = basAreaCylinder(r);
        System.out.println("arean är " + a);
    }

    static double basAreaCylinder(double radie){
        double area = Math.PI*radie*radie;
        return area;
    }

}
