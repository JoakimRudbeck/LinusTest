package kapitel_9;

public class metoder {

    public static void main(String[] args) {
    int x = 3;
    int svar = kvadratAv(x);
    System.out.println(x + " upphöjt till två är " + svar);

    }
    //metod som beräknar kvadrater
    static int kvadratAv(int tal){
        int kvadrat = tal * tal;
        return kvadrat;


    }

}

//void = att metoden inte returnerar något värde
