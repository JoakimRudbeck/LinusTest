package kapitel_9;

import java.util.Scanner;

public class tavlanÖvning {
    static Scanner scanner = new Scanner(System.in);


    public static void main(String[] args) {
        System.out.println("skriv in ett namn");
        String namn = scanner.nextLine();
        String utskrift = baklänges(namn);
        System.out.println(utskrift);
    }


    private static String baklänges(String namn) {
        String baklänges = "";
        for(int i = namn.length(); i>0; i--){
            baklänges += namn.substring(i-1,i);
        }
        return baklänges;





    }


}
