import java.util.Arrays;
import java.util.Scanner;

public class PROV_KAPITEL_1_8_LINUS_GERDIN {
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        Fråga1();


    }

    private static void Fråga1() {
        //skapar ett fält
        String kompisar[] = new String[3];

        System.out.println("Namn?");
        String namn = scan.nextLine();

        System.out.println("Ålder?");
        int ålder = Integer.valueOf(scan.nextLine());



//gör en loop som frågar efter användarens 3 vänner
        for(int i = 0; i < 3;i++ ){
            System.out.println("Kompis " + (i+1) + "?");
            kompisar[i] = scan.nextLine();

        }
//skriver ut halva anv namn
        String längd = namn.substring(0,namn.length()/2);
        System.out.println("halva ditt namn är " + längd);
//om åldern är mer än 18 skriver programmet ut att den är myndig
        if(ålder>18){
            System.out.println("användaren är myndig och du har levt i " + ålder * 365 + " dagar");

        }//annars är den inte myndig
        else{
            System.out.println("Användaren är inte myndig och du har levt i " + ålder * 365 + " dagar");
        }

        System.out.print("dina kompisar är: ");
        for(int n = 0; n < kompisar.length; n++){ //loopar för användarens antal kompisar
            System.out.print( kompisar[n].toUpperCase()); //skriver ut fältet m kompisar till stora bokstäver
            System.out.print(",");


        }






        System.out.println("\t");
        for(int i = 20; i>0; i--){ //gör en loop som går från 20 till 1
            System.out.print(i + " "); //skriver ut varje tal från 20 till 1
        }



    }



}
