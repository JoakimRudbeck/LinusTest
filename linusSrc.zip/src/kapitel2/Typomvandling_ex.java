package kapitel2;

import java.sql.SQLOutput;

public class Typomvandling_ex {

    public static void main(String[] args) {
        Typomvandling();
        test();

    }

    private static void test() {
        double a = 7;
        int b = 4;

        System.out.println(a/b);
    }

    private static void Typomvandling() {
        int a = 38300; //"38300"

        System.out.println("a = " + a);

        //hur många siffror innehåller talet a?
        String aSomString = String.valueOf(a); // int till sträng
        //strängen "38300"
        int antalSiffror = aSomString.length();
        System.out.println("Antal siffror i talet " + a + " är " + antalSiffror);
    }
}
