package kapitel2;

import java.util.Scanner;

public class Övningar {

    static Scanner inläsare = new Scanner(System.in);

    public static void main(String[] args) {
      //  Övning2_1();
       // Övning2_2();
        //Övning2_4();
        //Övning2_5();
        //Övning2_6();
        //Övning2_7();
        //Övning2_8();

    }

    private static void Övning2_8() {

    }

    private static void Övning2_7() {
        System.out.println("Skriv in ett tacken!");

        String namn = inläsare.nextLine();
        char tecken = namn.charAt(0);
        int teckenkod = (int)tecken;


        System.out.println(namn+" har koden "+teckenkod);

    }

    private static void Övning2_6() {
        System.out.println("Skriv in ditt namn vettja, gärna för och efternamn:");

        String namn = inläsare.nextLine();

        int mellanslag = namn.indexOf( ' ' );
        String förnamn = namn.substring(0,mellanslag);
        System.out.println("Förnamn: " + förnamn);

        String efternamn = namn.substring(mellanslag+1);
        System.out.println("Efternamn: " + efternamn);





    }

    private static void Övning2_5() {

        System.out.println("Skriv in ditt för- och efternamn här bramdem");
        char tecken;
        String namn = inläsare.nextLine();

        tecken = namn.charAt(0); //hittar första bokstaven i namnet


        int mellanslag = namn.indexOf( ' ' ); //hittar mellanslaget mellan för och efternamn
        char tecken2 = namn.charAt(mellanslag+1); //mellanslag +1 är första bokstaven i efternamnet.

        System.out.println(namn + " har initialerna " + tecken + "." + tecken2);


    }




    private static void Övning2_4() {

        System.out.println("Skriv in 3 heltal:");

        int a = inläsare.nextInt();
        int b = inläsare.nextInt();
        int c = inläsare.nextInt();

        int summa = a + b + c;
        System.out.println("Summan av dina tal är " + summa);

        int medelvärde = (a+b+c)/3;
        System.out.println("Medelvärdet av dina tal är " + medelvärde);

    }




    private static void Övning2_2() {


        System.out.println("Skriv in ett tal:");
        int tal = inläsare.nextInt();

        int summa = tal * tal;
        System.out.println("Ditt tal upphöjt i 2 är " + summa);





    }

    private static void Övning2_1() {
        System.out.println("Här kommer övning 2.1");

        double talA;
        double talB;
        double summa;

        talA = 2.1;
        talB = 3.1;
        summa = talA + talB;

        System.out.println("TalA är " + talA);
        System.out.println("TalB är " + talB);
        System.out.println("Summan är " + summa);
    }



}

