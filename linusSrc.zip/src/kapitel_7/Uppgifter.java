package kapitel_7;

import java.util.Scanner;

public class Uppgifter {

    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
       // Uppgift7_1();
       // Uppgift7_3();
        Uppgift7_4();


    }

    private static void Uppgift7_4() {
        





    }

    private static void Uppgift7_3() {

        System.out.println("Välj ett tal snabbt");
        int tal = Integer.valueOf(scanner.nextLine());

        if (tal > 0) {
            System.out.println("grattis du valde ett tal som är positivt");
        } else if (tal == 0) {
            System.out.println("bror ditt tal är 0");
        }
         else{
            System.out.println("ditt tal är negativt");
            }



    }


    private static void Uppgift7_1() {
        System.out.println("vill du svänga höger eller rakt fram");
        String vart = scanner.nextLine();

        if(vart.equalsIgnoreCase("höger")){
            System.out.println("Sväng höger");
        }
        else {
            System.out.println("fortsätt frammåt");
        }


    }


}
