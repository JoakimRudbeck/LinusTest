package kapitel_7;

import java.util.Scanner;

public class Övningar {

static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
      //  Övning7_1();
      //  Övning7_2();
       // Övning7_5();
     //  Övning7_6();
       // Övning7_7();
       // Övning7_8();
        




    }

    private static void Övning7_8() {
        System.out.println("Skriv in två namn");
        String namn1 = scanner.nextLine();
        String namn2 = scanner.nextLine();


        if(namn1.compareToIgnoreCase(namn2) < 0) {
            System.out.println(namn1);
            System.out.println(namn2);

        }
        else {
            System.out.println(namn2);
            System.out.println(namn1);

        }

    }

    private static void Övning7_7() {

        System.out.println("Mata in två tal: ");
        double tal1 = scanner.nextDouble();
        double tal2 = scanner.nextDouble();
        System.out.println("Hör kommer talen i storleksordning");

        if (tal1 >= tal2){
            System.out.println(tal1 + " ");
            System.out.println(tal2);
        }
        else{
            System.out.println(tal2 + " ");
            System.out.println(tal1);
        }

    }

    private static void Övning7_6() {

        double pris = 9.90;

        System.out.println("Hur många skivor köps:");
        int skivor = Integer.valueOf(scanner.nextLine());

        double faktor = 1;


        //gör flera else if för de olika intervallen av skivor som ger rabatter och sedan multiplicerar med faktorn för respektive rabatt.

        if (skivor > 10 && skivor < 50) {
            faktor = 0.95;
        }
        else if (skivor > 50 && skivor < 100) {
            faktor = 0.90;
        }

        else if (skivor > 100) {
            faktor = 0.85;
        }

        System.out.println("Skivorna kostar " + skivor * pris * faktor + " kr");






    }



    private static void Övning7_5() {

        double längd = 7.92;
        double vind = 2.0;

        System.out.println("hur långt hoppade du?");
        double tal = Double.valueOf(scanner.nextLine());

        System.out.println("vad är vindstyrkan?");
        double tal2 = Double.valueOf(scanner.nextLine());

        if(tal > vind && tal2 < vind){
            System.out.println("Grattis!");

        }
        else{
            System.out.println("bättre lycka nästa gång broshan");
        }


    }





    private static void Övning7_2() {

        int etanol = Integer.valueOf(scanner.nextLine());

        int fulltank = 50;

        double etanolpris = 9.50;

        if(etanol > 10)
        {
            System.out.println("Du behöver inte tanka");
        }
        else
        {
            System.out.println("Åk o tanka");
            int tankning = fulltank - etanol;
            double kostnad = tankning * etanolpris;
            System.out.println("Du ska tanka " + tankning + "liter och det kostar " + kostnad);
        }

    }




    private static void Övning7_1() {
        System.out.println("Hur gammal är du?");

        int ålder = Integer.valueOf(scanner.nextLine());

        if (ålder > 12) {
            System.out.println("Du får delta!");
        }
        else
            System.out.println("Du får ej delta!");












    }

}


