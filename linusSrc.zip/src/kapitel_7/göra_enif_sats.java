package kapitel_7;

public class göra_enif_sats {
    public static void main(String[] args) {


        String dag = "måndag";          //göra en if-sats, här kan du även ha en scanner
        int a = 4;
        if (dag.equals("måndag") && a > 10) {
            System.out.println("det är måndag");
        } else if (dag.equals("tisdag")) {
            System.out.println("det är tisdag");
        } else { //betyder i andra alla fall, om alla if skulle vara fel


        }


    }

}