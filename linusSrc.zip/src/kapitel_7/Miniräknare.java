package kapitel_7;

import java.util.Scanner;

public class Miniräknare {
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        //miniräknareVersion1();
        miniräknareVersion2();

    }

    private static void miniräknareVersion2() {
        //Läs in strängen "A operator B"
        System.out.println("Skriv in A operator B");
        String indata = scanner.nextLine();

        //Sug ut talet A ur strängen
        String[] splittad = indata.split(" "); //{"A", "*","B"} //splittar på mellanslag
        int a = Integer.valueOf(splittad[0]);

        //Sug ut talet B ur strängen
        int b = Integer.valueOf(splittad[2]);
        //Sug ut operatorn ur strängen
        String operator = (splittad[1]);

        //Beräkna värdet av A operator B (baserat på operatorn)

        switch(operator) {
            case "+":
                System.out.println(a+b);
                break;
            case "*":
                System.out.println(a*b);
                break;
            case "%":
                System.out.println(a%b);
                break;
            default:  // om användaren inte skriver in +,*,%
                System.out.println("Jag uppfattade inte din operator");

        }









    }

    private static void miniräknareVersion1() {
        //Läs in strängen "A operator B"
        System.out.println("Skriv in A operator B");
        String indata = scanner.nextLine();

        //Sug ut talet A ur strängen
        String[] splittad = indata.split(" "); //{"A", "*","B"} //splittar på mellanslag
        int a = Integer.valueOf(splittad[0]);

        //Sug ut talet B ur strängen
        int b = Integer.valueOf(splittad[2]);
        //Sug ut operatorn ur strängen
        String operator = (splittad[1]);

        //Beräkna värdet av A operator B (baserat på operatorn)

        if(operator.equals("+")){  //använder equals inte ==
            System.out.println(a+b);
        }
        else if(operator.equals("*")){
            System.out.println(a*b);
        }
        else if(operator.equals(a%b)){
            System.out.println(a%b);
        }
        else {
            System.out.println("Jag uppfattade inte din operator");
        }


        //Skriva ut värdet
    }


}

