package kapitel6;


import java.util.Scanner;

public class Övningar {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        Övning6_1();
        Övning6_2();
        Övning6_3();

    }

    private static void Övning6_3() {



    }

    private static void Övning6_2() {
        //gjord i paint o grabbarna





    }

    private static void Övning6_1() {
        int tal1, tal2, tal3;
        System.out.println("Mata in 3 heltal");

        tal1 = Integer.valueOf(scanner.nextLine());
        tal2 = Integer.valueOf(scanner.nextLine());
        tal3 = Integer.valueOf(scanner.nextLine());

        tal1 *= 2;
        tal2 *= 3;
        tal3 *= 4;

        int summa = tal1 + tal2 + tal3;
        System.out.println("Summan av talen är " + summa);

    }

}
