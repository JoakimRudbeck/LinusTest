import java.util.Arrays;
import java.util.Scanner;

public class PROV_KAPITEL_1_8_LINUS_GERDIN_KOMPLETTERING_KRÄVS {

    /*
    Beräkna antal bokstäver i kompisarnas namn, åtgärda detta för E.
     */
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        Fråga1();
        aUppgiften();


    }

    private static void aUppgiften() {





    }

    private static void Fråga1() {
        //skapar ett fält

        System.out.println("Hur många kompisar vill du skriva in?");
        int antalkompisar = Integer.valueOf(scan.nextLine());

        String kompisar[] = new String[antalkompisar];


        System.out.println("Namn?");
        String namn = scan.nextLine();

        System.out.println("Ålder?");
        int ålder = Integer.valueOf(scan.nextLine());


//gör en loop som frågar efter användarens 3 vänner
        for (int i = 0; i < antalkompisar; i++) {
            System.out.println("Kompis " + (i + 1) + "?");
            kompisar[i] = scan.nextLine();

        }
//skriver ut halva anv namn
        String längd = namn.substring(0, namn.length() / 2);
        System.out.println("Halva ditt namn är " + längd);
//om åldern är mer än 18 skriver programmet ut att den är myndig
        if (ålder > 18) {
            System.out.println("Användaren är myndig och du har levt i " + ålder * 365 + " dagar");

        }//annars är den inte myndig
        else {
            System.out.println("Användaren är inte myndig och du har levt i " + ålder * 365 + " dagar");
        }

        System.out.print("Dina kompisar är: ");
        for (int n = 0; n < kompisar.length; n++) { //loopar för användarens antal kompisar
            if(kompisar[n].length()%2==0){ //ifall namnets längd är %2 == 0 så skrivs det ut med stora bokstäver
                System.out.print(kompisar[n].toUpperCase());
                System.out.print(", ");
            }
            else{
                System.out.print(kompisar[n].toLowerCase()); //annars om talet har ett udda antal bokstäver skrivs de ut med små bokstäver
                System.out.print(", ");
            }
        }
        System.out.println("");
        int bokstäverIkompisarsNamn = 0;
//loop som loopar genom antalet kompisar som användaren skrivit in. loopen ser hur många bokstäver som finns i varje fält.
        for (int i = 0; i < antalkompisar; i++) {
            bokstäverIkompisarsNamn += kompisar[i].length();
        }
//skriver ut antalet bokstäver i kompisarnas namn
            System.out.println("Dina kompisar halt totalt " + bokstäverIkompisarsNamn + " bokstäver i sig" );



            for (int a = 20; a > 0; a--) { //gör en loop som går från 20 till 1
                System.out.print(a + " "); //skriver ut varje tal från 20 till 1
            }


        }

    }


