package kapitel8;

import java.util.Random;
import java.util.Scanner;


public class dowhileloop {
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        String köra = "JA";
        do {
            Random r = new Random(); //skapar ett random objekt
            int a = r.nextInt(50); //slumpar ett tal mellan 0 och 9
            int b = r.nextInt(50);
            System.out.println("Vad blir " + a + "+" + b + "?");
            int svar = Integer.valueOf(scan.nextLine());
            if (svar == a + b) {
                System.out.println("RÄTT");
            }
            else{
                System.out.println("FEL");
            }
            System.out.println("igen? JA/NEJ");
            köra =scan.nextLine();

        }
        while (köra.equals("JA"));

    }

}
//do while loop gör minst 1 varv, den kollar villkoret innan.
//continue = avslutar varvet o hoppar till västa varv i loopen
//break = avslutar och hoppar ur loopen helt.