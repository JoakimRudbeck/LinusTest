package kapitel8;


import java.util.Scanner;

public class tavlanProblem {
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        // fruktTavla();
       // eÖvning1();
       // eÖvning2();
       // eÖvning2igen();
        eÖvning3();
       // eÖvning3fält();

    }

    private static void eÖvning3fält() {
        int sammaBokstav = 0;
        int N = Integer.valueOf(scan.nextLine());
        String fält[] = new String[N];


        System.out.println("bokstav?");
        String bokstav = scan.nextLine().toLowerCase();

        for(int i = 0; i < fält.length; i++){
            if(fält[i].toLowerCase().contains(bokstav)){
                sammaBokstav++;
            }
        }


        System.out.println(bokstav);







    }

    private static void eÖvning3() {

        //frågar användaren efter bokstav och ord och sedan kollar den hur många bokstäver som finns i det ordet.

        int antal = 0;

        System.out.println("Skriv in ett ord");
        String s = scan.nextLine();

        System.out.println("Skriv in en bokstav");
      // char t = scan.nextLine().charAt(0);
       String t = scan.nextLine().substring(0,1);

        for (int i = 0; i < s.length(); i++) {
            if(("" + s.charAt(i)).equalsIgnoreCase(t)){ //man behöver string när man använder contains därav ""
                antal++;



            }


        }
        System.out.println("det finns " + antal + " " +  t + " i ditt ord");




        }






    private static void eÖvning2igen() {
        //do while lopp som fortsätter om namnet inte är zlatan

        while(true){
            System.out.println("namn: ");
            String namn = scan.nextLine();

            if(namn.equalsIgnoreCase("Zlatan")){
                break;
            }
            else{
                System.out.println("kön: ");
                String kön = scan.nextLine();

                System.out.println("ålder: ");
                int ålder = Integer.valueOf(scan.nextLine());

                System.out.println("favoritmat: ");
                String mat = scan.nextLine();

                if(ålder > 18){
                    System.out.println("Du heter " + namn + " och är en myndig " + kön + " samt din favomat är " + mat);
                }
                else{
                    System.out.println("Du heter " + namn + " och är en icke-myndig " + kön + " samt din favomat är " + mat);
                }

            }


        }








    }

    private static void eÖvning2() {

    }
//














    private static void eÖvning1() {
        for (int i = 0; i <= 50; i += 5) { // skriver ut var femte tal 0 - 50
            if (i % 10 == 0) { //om talet är = 0 om man kör modulo 10 skriv ut X
                System.out.println("X");
            }
            else
                System.out.println(i);

        }


    }




    private static void fruktTavla() {
        int sammaBokstav = 0; // kolla hur många bokstäver

        System.out.println("hur många frukter vill du ha?:");
        int N = Integer.valueOf(scan.nextLine());
        String fält[] = new String[N]; //skapar fält med scan





        System.out.println("Skriv in namn på dina frukter:");

        for (int i = 0; i < fält.length; i++) {
            System.out.println("Vad är frukt " + (i+1) + "?");
            fält[i] = String.valueOf(scan.nextLine());

        }

        System.out.println("bokstav?");
        String bokstav = scan.nextLine().toLowerCase();

        for(int i = 0; i < fält.length; i++){
            if(fält[i].toLowerCase().contains(bokstav)){
                sammaBokstav++;
            }
        }

        System.out.println(sammaBokstav + "av alla frukter har bkstaven " + bokstav + " i sig");

        System.out.println((sammaBokstav)*100.0/fält.length + "procent av frukterna har bokstaven " + bokstav + "i sig") ;



    }



        }










