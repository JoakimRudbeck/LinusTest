package kapitel8;

import java.util.Scanner;

public class göraEnForLoop {
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
       // förstaForLoopen();
       // andraForLoopnn();
        ////tredjeForLoopen();
        //enLoopFörFält();
       // loop_1();
        // kordinatLoop();
       kordinatLoop2();



    }

    private static void kordinatLoop2() {
        System.out.println("xMax");
        int xMax = Integer.valueOf(scanner.nextLine());
        System.out.println("yMax");
        int yMax = Integer.valueOf(scanner.nextLine());

        System.out.println("punktens x koordinat?");
        int Px = Integer.valueOf(scanner.nextLine()); //Px = punktens x koordinat

        System.out.println("punktens y koordinat?");
        int Py = Integer.valueOf(scanner.nextLine());

        System.out.println("punktens  markering?");
        String markör = scanner.nextLine();



        System.out.println("andra punktens x koordinat?");
        int Ox = Integer.valueOf(scanner.nextLine()); //Px = punktens x koordinat

        System.out.println("andra punktens y koordinat?");
        int Oy = Integer.valueOf(scanner.nextLine());

        System.out.println("andra punktens markering?");
        String markör2 = scanner.nextLine();



        for(int y=yMax; y>=0; y--){
            for(int x = 0; x <= xMax; x++){
                if(x == Px && y == Py && x == Ox && y == Oy){
                    System.out.print(markör + "\t\t");
                    System.out.println(markör2 + "\t\t");
                }
                else{
                    String koordinat = "(" + x + "," + y + ")";
                    System.out.print(koordinat + "\t");
                }

            }
            System.out.println();
        }



    }

    private static void kordinatLoop() {
        //System.out.println("skriv in x");
        //int x = Integer.valueOf(scanner.nextLine());

        //System.out.println("skriv in y");
        //int y = Integer.valueOf(scanner.nextLine());

        for(int i = 5; i >= 0; i--) {
            for (int n = 5; n > 0; n--) {
                System.out.print(i+n + " ");
            }
            System.out.println();
        }
    }

    private static void loop_1() {
        //för varje rad:
        for(int i = 1; i <=5; i++){
            //för varje kolumn:
            for(int n = 1; n <=4; n++){     //en loop i en loop, använder man två olika variabler. i detta fall i och n
                System.out.print(i*n + " ");

            }
            System.out.println("hej"); // efter varje rad kommer ett enterslag, eller ett hej i detta fall för att visa
                                        // System.out.println(); blir bara ett enterslag.

        }


    }

    private static void enLoopFörFält() {

        String[] frukter = new String[4];

        for(int i = 0; i < 4; i++) {
            System.out.println("Frukt" + (i + 1) + "?");        //en loop istället för fält
            frukter[i] = scanner.nextLine();
        }
        System.out.println("Alla frukter i fältet");
        {
            for (int i = 0; i <= 3; i++)
                System.out.println(frukter[i]);
        }

    }

    private static void tredjeForLoopen() {




    }

    private static void andraForLoopnn() {

        for(int i = 1; i<6; i++) {
            System.out.println(i); // kommer att skriva ut 1 2 3 4 5.
        }

    }

    private static void förstaForLoopen() {

        for(int i = 3; i<8; i++) { //i = iterationsvärde, i<8 = villkor, i++ = förändring

            System.out.println(i + 7);
        }

    }


}
