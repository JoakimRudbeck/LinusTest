package kapitel8;

public class akesProblemlös {

    public static void main(String[] args) {
        //loopar alla udda tal

        for (int i = 1; i <= 10000; i+=2) {
            //kolla om i e delbart med 7
            if(i%7==0){
                String tal = "" + i;
                int antalFemmor = 0;
                //Loopar igenom varje tecken i tal
                for(int a = 0; a<tal.length(); a++){
                    if(tal.charAt(a) == '5'){
                        antalFemmor++;
                    }

                }

                if(antalFemmor == 2){
                    System.out.println(i);
                }

            }

        }
    }






}