package kapitel8;


import java.util.Scanner;

public class Uppgifter {
    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        //Uppgift8_1();
       //Uppgift8_1b();
       // Uppgift8_1c();
       // Uppgift8_2();
        Uppgift8_3a();


    }

    private static void Uppgift8_3a() {

        System.out.println("hur många *?");
        //st = stjärna
        char st = scanner.nextLine().charAt(0);
        String st1 = scanner.nextLine();







    }

    private static void Uppgift8_2() {
        int[] f = {1,2,3,4,5};

        int temp = f[0];
        f[0] = f[4];
        f[4] = temp;

        int temp2 = f[1];
        f[1] = f[3];
        f[3] = temp2;

        for(int i = 0; i < f.length; i++){
            System.out.println(f[i]);

        }



    }

    private static void Uppgift8_1c() {
        int i = 3;

        do {
            System.out.println(i++);
        }
    while (i <= 10);



    }

    private static void Uppgift8_1b() {
        int i = 3;
        while (i <= 10) {
            System.out.print(i++);

        }


    }

    private static void Uppgift8_1() {
        for(int i = 3; i <= 10; i++ ) {
            System.out.print(i);

        }

    }


}
