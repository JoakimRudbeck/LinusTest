package kapitel8;


import java.util.Scanner;

public class Övningar {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        //Övning8_1();
        // Övning8_2();
      //  Övning8_4();
       // Övning8_5();
      //  Övning8_6();
        //Övning8_7();
        //Övning8_8();
        Övning8_9();



    }

    private static void Övning8_9() {
        double behållning = 1000; //start saldo på 1000 kr

        //visar menyn
        System.out.println("MENY");
        System.out.println("1. Insättning");
        System.out.println("2. Uttag");
        System.out.println("3. Visa behållning");
        System.out.println("4.Avsluta programmet");


        //val av meny i bank-programmet
        String meny = scanner.nextLine();
        switch(meny) {
            case "insättning":
                System.out.println("hur mke ska du lägga in broshan");
                double insättning = Double.valueOf(scanner.nextLine());
                behållning = behållning + insättning;
                System.out.println("ditt nya saldo e " + behållning + " abow rik kille");
                break;
            case "uttag":
                System.out.println("hur mke ska du ta ut?");
                double uttag = Double.valueOf(scanner.nextLine());
                uttag = behållning - uttag;
                System.out.println("ditt nya saldo är " + uttag + " ");
                break;
            case "visa behålllning":
                System.out.println("Detta är ditt saldo just nu!: " + behållning);

                break;
            case "ja":
                System.out.println("Avsluta?");
                break;
            default:
                System.out.println("Fel");


        }
    }





    private static void Övning8_8() {
        System.out.println("Miniräknare:\n\n");
        System.out.println("Beräknar produkten av två tal");
        System.out.println("Tryck n för att avbryta");

        char fortsätt;
        int tal1, tal2;
        do {
            System.out.println("\n\n");
            System.out.println("tal 1 : ");
            tal1 = Integer.valueOf(scanner.nextLine());
            System.out.println("tal 2 : ");
            tal2 = Integer.valueOf(scanner.nextLine());

            System.out.println(tal1 + "*" + tal2 + "=" + (tal1 * tal2));

            System.out.println("fortsätt? (j\n): ");
            fortsätt = scanner.next().charAt(0);
        }
        while ((fortsätt != 'n'));
    }





    private static void Övning8_7() {
        System.out.println("skriv in tal 1");
        double tal1 = Double.valueOf(scanner.nextLine());
        System.out.println("skriv in tal 2");
        double tal2 = Double.valueOf(scanner.nextLine());


        System.out.println("Skriv in den metod du vill använda");
        System.out.println("Räknesätten: 1=+ , 2=- , 3=* , 4=/");
        int räknesätt = Integer.valueOf(scanner.nextLine());
        switch(räknesätt){
            case 1 :
                System.out.println("Svar: " + (tal1 + tal2));
            break;
            case 2:
                System.out.println("Svar: " + (tal1 -tal2));
            break;
            case 3:
                System.out.println("Svar: " + (tal1 * tal2));
            break;
            case 4:
                System.out.println("Svar: " +  (tal1 / tal2));
                break;
            default:
                System.out.println("Felinmatning");


        }




    }

    private static void Övning8_6() {
        int folkmängd = 1000000;
        int år = 0;


        while(folkmängd < 2000000)
        {
            folkmängd=(int)(folkmängd*1.05);
            år++;
        }
        System.out.println(år);



    }

    private static void Övning8_5() {

        for (int i = 1;i <= 10; i++ ) { //detta är första raden neråt 1-10
            for (int n = 1; n <= i; n++) { //en andra loop som tar
                System.out.print(i*n + "\t"); //för att få utskriften på olika rader tar man bort ln i slutet av en sout.
            }
            System.out.println();

        }


    }

    private static void Övning8_4() {

        System.out.println("Hur många värden vill du ha");
        int antal = Integer.valueOf(scanner.nextLine());

        //fyller fälten med värden
        int[] tal = new int[5];
        for (int i = 0; i < tal.length; i++) { //här kommer användaren skriva in hur många gånger loopen kommer att gå.
            System.out.println("tal" + (i + 1) + "?");
            tal[i] = Integer.valueOf(scanner.nextLine());
        }
        //letar efter minsta värdet
        int minsta = tal[0]; //minsta är i detta fall det första talet, plats [0]
        for (int i = 0; i < minsta; i++) {
            if (minsta > tal[i]) {
                minsta = tal[i]; //if det minsta talet är större än tal i då är det nya talet minsta.
            }
        }
        System.out.println();
        System.out.println("minsta värdet: " + minsta);

    }




    private static void Övning8_2() {
        System.out.println("Skriv in det minsta talet");
        int minsta = Integer.valueOf(scanner.nextLine());

        System.out.println("Skriv in det största talet");
        int största = Integer.valueOf(scanner.nextLine());


        System.out.println("Skriv in steglängden mellan dina tal");
        int steg = Integer.valueOf(scanner.nextLine());

        for(int i = minsta; i<största; i +=steg){
            System.out.println(i);
        }


    }

    private static void Övning8_1() {
        for(int i = 10; i<=25; i++){
            System.out.print(i + " ");
        }




    }


}
