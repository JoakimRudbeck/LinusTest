import java.util.Scanner;

public class PROV_KAP1_4_LINUS_GERDIN {

    static Scanner Scanner = new Scanner(System.in); //gör en scanner

    public static void main(String[] args) {
        //Vad användarens namn är
        System.out.println("Vad heter du?"); //frågar användaren vad hen heter
        String namn = Scanner.nextLine(); //en scanner där användaren kommer att skriva in sitt namn.


        //Hur många bokstäver som namnet består av
        int längd = namn.length(); //detta beräknar hur många bokstäver som finns i variabeln namn
        System.out.println("Du heter " + namn.toUpperCase() + " och ditt namn består av " + längd + " bokstäver");
        //skriver ut vad man heter i stora bokstäver genom att använda toUpperCase




        //att skriva in ett heltal
        System.out.println("Skriv in ett heltal"); //ber användaren skriva in ett heltal
        int a = Integer.valueOf(Scanner.nextLine()); //En scanner som tar in vad användaren skriver, till variabeln a

        System.out.println("Skriv in ett till heltal"); //samma sak fast för variablen b
        int b = Integer.valueOf(Scanner.nextLine());


        int summan = a + b; //beräknar summan av a+b
        System.out.println("Summan av talen du skrivit in är " + summan);

        int produkten = a*b; //beräknar produkten
        System.out.println("Produkten av dina tal är " + produkten);

        int modulu = a%b; //beräknar resten
        System.out.println("Resten som blir när du dividerar a och b blir " +modulu);





        //skapa ett fält med frutkter


        String[] frukter = new String [4]; //gör ett fält

        System.out.println("Frukt 1:");
        frukter[0] = (Scanner.nextLine()); //lägger scanner till varje fält där anvndaren skriver in

        System.out.println("Frukt 2:");
        frukter[1] = (Scanner.nextLine());

        System.out.println("Frukt 3:");
        frukter[2] = (Scanner.nextLine());

        System.out.println("Frukt 4:");
        frukter[3] = (Scanner.nextLine());

        System.out.println("Alla frukter i fältet");
        System.out.println(frukter[0]);
        System.out.println(frukter[1]);
        System.out.println(frukter[2]);
        System.out.println(frukter[3]);




        //byta plats och ändra i fältet


        String temp = frukter[0]; //byter plats på första o sista platsen
        frukter[0] = frukter [3];
        frukter[3] = temp;

        frukter[1] = "KIWI"; //byter namn till KIWI


        frukter[2] = namn.substring(0,3); // halva namnet

        //skriver ut det nya fältet en sista gång
        System.out.println("Alla värden i fältet efter ändringarna:");
        System.out.println(frukter[0]);
        System.out.println(frukter[1]);
        System.out.println(frukter[2]);
        System.out.println(frukter[3]);






    }
}
